package javakasir;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class JavaKasir {

    public static void main(String[] args) {

        ArrayList<Barang> dataBarang = new ArrayList<>();

        String fileName = "D:\\algoritma dan struktur data\\JavaKasir\\src\\javakasir\\DataBarang.txt";
        String transaksi = "D:\\algoritma dan struktur data\\JavaKasir\\src\\javakasir\\DataTransaksi.txt";
        boolean running = true;
        int id = -1;
        int i = -1;

        while (running) {

            System.out.println("=============================");
            System.out.println("            M E N U          ");
            System.out.println("=============================");
            System.out.println(" [T]. TAMBAH BARANG         +");
            System.out.println(" [V]. VIEW DATA BARANG      +");
            System.out.println(" [TSB]. TAMBAH STOCK BARANG +");
            System.out.println(" [R]. REMOVE DATA BARANG    +");
            System.out.println(" [P]. PENJUALAN             +");
            System.out.println(" [X]. EXIT                  +");
            System.out.println("----------------------------+");

            Scanner scan = new Scanner(System.in);
            System.out.print("Masukkan Pilihan : ");
            String opsi = scan.next();
            System.out.println("-------------------------------");
            if (opsi.equalsIgnoreCase("V")) {
                System.out.println("-----------------------------------------------------------------");
                System.out.println("id\t" + "barang\t\t" + "stock\t\t" + "terjual\t\t" + "harga\n");
                try {
                    File myFile = new File(fileName);
                    Scanner fileReader = new Scanner(myFile);

                    while (fileReader.hasNextLine()) {
                        String data = fileReader.nextLine();
                        System.out.println(data);
                    }
                    System.out.println("-----------------------------------------------------------------");
                } catch (IOException e) {
                    System.out.println("Terjadi Kesalahan " + e.getMessage());
                }

            } else if (opsi.equalsIgnoreCase("T")) {
                System.out.print("Nama Barang   : ");
                String namaBarang = scan.next();
                System.out.print("Stock ? : ");
                int jumlahBarang = scan.nextInt();
                System.out.print("Harga   : ");
                int hargaBarang = scan.nextInt();
                int terjual = 0;

                System.out.println("-------------------------------");
                System.out.print("Ingin Meyimpan data Y/T ? ");
                String save = scan.next();
                System.out.println("-------------------------------");
                if (save.equalsIgnoreCase("y")) {
                    id++;
                    i++;
                    dataBarang.add(new Barang(id, namaBarang, jumlahBarang, hargaBarang, terjual));
                    System.out.println("Berhasil Menyimpan Data");
                    try {
                        FileWriter fileWriter = new FileWriter(fileName, true);
                        fileWriter.append(dataBarang.get(i).id + "\t" + dataBarang.get(i).namaBarang + "\t\t" + dataBarang.get(i).stockBarang + "\t\t" + dataBarang.get(i).terjual + "\t\t" + dataBarang.get(i).hargaBarang + "\n");
                        fileWriter.close();
                    } catch (IOException e) {
                        System.out.println("Terjadi Kesalahan" + e.getMessage());
                    }
                } else {
                    System.out.println("-------------------------------");
                    System.out.println("Penambahan Barang Di Batalkan");
                }
            }
            if (opsi.equalsIgnoreCase("TSB")) {
                int index = -1;
                boolean ditemukan = false;
                System.out.println("------------------------------");
                System.out.println("=====TAMBAH STOCK BARANG======");
                System.out.println("------------------------------");
                System.out.print("Masukkan Id :");
                int kodeBarang = scan.nextInt();
                for (int j = 0; j < dataBarang.size(); j++) {
                    if (dataBarang.get(j).id == kodeBarang) {
                        index = j;
                        ditemukan = true;
                    }
                }
                if (ditemukan == true) {
                    System.out.print("Jumlah Penambahan Stock : ");
                    int tambahStock = scan.nextInt();
                    System.out.println("-------------------------------");
                    System.out.print("Yakin Ingin Menambah y/t ? ");
                    String tambah = scan.next();
                    System.out.println("-------------------------------");
                    if (tambah.equalsIgnoreCase("y")) {
                        Barang updateStock = dataBarang.get(kodeBarang);
                        updateStock.stockBarang = dataBarang.get(kodeBarang).stockBarang + tambahStock;
                        System.out.println("Penambahan Stock Barang Berhasil");
                        try {
                            FileWriter fileWriter = new FileWriter(fileName, false);
                            for (Barang barangku : dataBarang) {
                                fileWriter.append(barangku.id + "\t" + barangku.namaBarang + "\t\t" + barangku.stockBarang + "\t\t" + barangku.terjual + "\t\t" + barangku.hargaBarang + "\n");
                            }
                            fileWriter.close();
                        } catch (IOException e) {
                            System.out.println("Terjadi Kesalahan " + e.getMessage());
                        }
                    } else {
                        System.out.println("----------------------------------");
                        System.out.println("Penambahan Stock Barang Dibatalkan");
                    }
                } else {
                    System.out.println("-------------------------------------");
                    System.out.println("Id Yang Anda Masukkan Tidak Ditemukan");
                }
            }

            if (opsi.equalsIgnoreCase("R")) {
                int index = -1;
                boolean ditemukan = false;
                System.out.print("Hapus Barang Dengan Id : ");
                int hapus = scan.nextInt();

                for (int j = 0; j < dataBarang.size(); j++) {
                    if (dataBarang.get(j).id == hapus) {
                        index = j;
                        ditemukan = true;
                    }
                }
                if (ditemukan == true) {
                    System.out.print("apakah Anda Yakin Akan Menghapusnya y/t ? ");
                    String hapusBarang = scan.next();
                    if (hapusBarang.equalsIgnoreCase("y")) {
                        dataBarang.remove(hapus);
                        System.out.println("Data Barang Berhasil Di Hapus");
                        try {
                            FileWriter fileWriter = new FileWriter(fileName, false);
                            for (Barang barangku : dataBarang) {
                                fileWriter.append(barangku.id + "\t" + barangku.namaBarang + "\t\t" + barangku.stockBarang + "\t\t" + barangku.terjual + "\t\t" + barangku.hargaBarang + "\n");
                            }
                            fileWriter.close();
                        } catch (IOException e) {
                            System.out.println("Terjadi Kesalahan  " + e.getMessage());
                        }
                    } else {
                        System.out.println("========================");
                        System.out.println("Penghapusan Di Batalakan");
                    }
                } else {
                    System.out.println("=====================================");
                    System.out.println("Id Yang Anda Masukkan Tidak Ditemukan");
                }
            }
            if (opsi.equalsIgnoreCase("P")) {
                System.out.println("=================================================================");
                System.out.println("id\t" + "barang\t\t" + "stock\t\t" + "terjual\t\t" + "harga\n");
                System.out.println("=================================================================");
                try {
                    File myFile = new File(fileName);
                    Scanner fileReader = new Scanner(myFile);

                    while (fileReader.hasNextLine()) {
                        String data = fileReader.nextLine();
                        System.out.println(data);
                    }
                    System.out.println("-----------------------------------------------------------------");
                } catch (IOException e) {
                    System.out.println("Terjadi Kesalahan " + e.getMessage());
                }
                System.out.println("-----------------------------------------------------------------");
                System.out.print("Id Barang Yang Dibeli : ");
                int pilihBarang = scan.nextInt();
                int index = -1;
                boolean ditemukan = false;
                for (int j = 0; j < dataBarang.size(); j++) {
                    if (dataBarang.get(j).id == pilihBarang) {
                        index = j;
                        ditemukan = true;
                    }
                }
                if (ditemukan == true) {
                    System.out.println("-------------------------------");
                    System.out.print("Jumlah Barang Belanjaan : ");
                    int jumlahBelanjaan = scan.nextInt();
                    Barang update = dataBarang.get(pilihBarang);
                    update.stockBarang = dataBarang.get(pilihBarang).stockBarang - jumlahBelanjaan;
                    update.terjual = dataBarang.get(pilihBarang).terjual + jumlahBelanjaan;
                    try {
                        FileWriter fileWriter = new FileWriter(fileName, false);
                        for (Barang barangku : dataBarang) {
                            fileWriter.append(barangku.id + "\t" + barangku.namaBarang + "\t\t" + barangku.stockBarang + "\t\t" + barangku.terjual + "\t\t" + barangku.hargaBarang + "\n");
                        }
                        fileWriter.close();
                    } catch (IOException e) {
                        System.out.println("Terjadi Kesalahan karena: " + e.getMessage());
                    }

                    try {
                        FileWriter fileWriter = new FileWriter(transaksi, true);
                        fileWriter.write("------------------------------------------------------");
                        fileWriter.write("\nStruk belanja                                       ");
                        fileWriter.write("\n----------------------------------------------------");
                        fileWriter.write("\nId            : " + pilihBarang);
                        fileWriter.write("\nNama Barang   : " + dataBarang.get(index).namaBarang);
                        fileWriter.write("\nStock         : " + jumlahBelanjaan);
                        fileWriter.write("\nHarga         : " + dataBarang.get(index).hargaBarang);
                        fileWriter.write("\n-----------------------------------------------------");
                        fileWriter.write("\nTotal         : " + dataBarang.get(index).hargaBarang * jumlahBelanjaan);
                        fileWriter.write("\n-----------------------------------------------------");
                        fileWriter.close();
                    } catch (IOException e) {
                        System.out.println("Terjadi Kesalahan" + e.getMessage());
                    }
                    try {
                        File myFile = new File(transaksi);
                        Scanner fileReader = new Scanner(myFile);

                        while (fileReader.hasNextLine()) {
                            String data = fileReader.nextLine();
                            System.out.println(data);
                        }

                    } catch (IOException e) {
                        System.out.println("Terjadi Kesalahan" + e.getMessage());
                    }
                } else {
                    System.out.println("-------------------------------");
                    System.out.println("Id Yang Anda Masukkan Tidak Ditemukan");
                    System.out.println("");
                }
            } else if (opsi.equalsIgnoreCase("X")) {
                break;
            }
        }
    }
}
